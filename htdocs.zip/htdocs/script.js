//Sidebar
const body = document.querySelector('body'),
      sidebar = body.querySelector('nav'),
      toggle = body.querySelector(".toggle"),
      searchBtn = body.querySelector(".search-box"),
      modeSwitch = body.querySelector(".toggle-switch"),
      modeText = body.querySelector(".mode-text");


toggle.addEventListener("click" , () =>{
    sidebar.classList.toggle("close");
})

searchBtn.addEventListener("click" , () =>{
    sidebar.classList.remove("close");
})

modeSwitch.addEventListener("click" , () =>{
    body.classList.toggle("dark");
    
    if(body.classList.contains("dark")){
        modeText.innerText = "Light mode";
    }else{
        modeText.innerText = "Dark mode";
        
    }
});

//Mlife Section
function sharePost(platform) {
    let url = '';
    const postUrl = window.location.href;

    switch(platform) {
        case 'whatsapp':
            url = `https://api.whatsapp.com/send?text=${encodeURIComponent(postUrl)}`;
            break;
        case 'facebook':
            url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(postUrl)}`;
            break;
        case 'message':
            url = `sms:?&body=${encodeURIComponent(postUrl)}`;
            break;
        case 'email':
            url = `mailto:?subject=Check this out&body=${encodeURIComponent(postUrl)}`;
            break;
    }

    window.open(url, '_blank');
}

//Profile
function increaseLike(likeId) {
    const likeElement = document.getElementById(likeId);
    let likes = parseInt(likeElement.textContent);
    likes++;
    likeElement.textContent = likes;
}

function submitComment(commentId) {
    const commentElement = document.getElementById(commentId);
    let comments = parseInt(commentElement.textContent);
    comments++;
    commentElement.textContent = comments;
    // Here you can add more code to actually submit the comment, e.g., send to server
}

//SLider Section
const swiper = new Swiper('.slider-wrapper', {
    loop: true,
    spaceBetween: 50,
    grabCursor: true,
    autoplay: {
        delay: 2000, // Delay between transitions in milliseconds
        disableOnInteraction: false, // Enable autoplay even after user interactions
    },

    // If we need pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
        dynamicsBullets: true,
    },

    // Navigation arrows
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },

    // Responsive breakpoints
    breakpoints: {
        0: { slidesPerView: 1 },
        576: { slidesPerView: 2 },
        1170: { slidesPerView: 3 },
    }
});

//client section owl carousel
$(".owl-carousel").owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    dots: false,
    navText: [
        '<i class="fa fa-long-arrow-left" aria-hidden="true"></i>',
        '<i class="fa fa-long-arrow-right" aria-hidden="true"></i>'
    ],
    autoplay: true,
    autoplayHoverPause: true,
    responsive: {
        0: {
            items: 1
        },
        768: {
            items: 2
        },
        1000: {
            items: 2
        }
    }
});

/** google_map js **/
function myMap() {
    var mapProp = {
        center: new google.maps.LatLng(40.712775, -74.005973),
        zoom: 18,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
}